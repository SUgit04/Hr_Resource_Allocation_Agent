from langgraph.graph import StateGraph, END
from state.schemas import AgentState
from nodes.intent_classifier import classify_intent
from nodes.leave_management import check_leave_status, process_leave_request, submit_leave_application

def route_after_intent(state: AgentState):
    if state.get("awaiting_user"):
        return state["next_node"]
    if state.get("intent") == "leave_management":
        return "check_leave_status"
    return END

def create_workflow():
    g = StateGraph(AgentState)

    # Nodes
    g.add_node("classify_intent", classify_intent)
    g.add_node("resource_allocation", resource_allocation)
    g.add_node("handle_approval", handle_approval)
    g.add_node("handle_unclear", handle_unclear)
    g.add_node("handle_other", handel_other)
    g.add_node("handle_exit", handle_exit)

    g.set_entry_point("classify_intent")

    # Conditional edges
    g.add_conditional_edges(
        "classify_intent",
        route_after_intent,
        {
            "resource_allocation": "classify_intent",
            "resource_allocation": "resource_allocation",
            "handle_approval": "submit_leave",
            "handle_unclear":"handle_unclear",
            "handle_other":"handle_other",
            "handle_exit":"handle_exit"

            END: END
        }
    )

    # Linear edges (for fallback)
    g.add_edge("handle_unclear", END)
    g.add_edge("handle_other", END)
    g.add_edge("handle_exit", END)

    return g.compile()

graph = create_workflow()
