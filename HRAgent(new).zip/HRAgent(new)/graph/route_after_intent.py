def route_after_intent(state: AgentState) -> Literal[
    "check_jd_status",
    "check_leave_status",      # <-- ADD
    "handle_other",
    "handle_unclear",
    "handle_exit"
    "handle_approval"
]:
    """Route based on classified intent."""
    
    
    intent = llm.invoke(intent).content.strip().lower()
    current_agent = state.get("current_agent")

    # Check if already in an active agent workflow
    if current_agent and not state.get("agent_completed", False):
        if current_agent == "resource_allocation":
            return "check_jd_status"
        elif current_agent == "leave_management":   # <-- ADD
            return "check_leave_status"             # <-- ADD

    # Route based on new intent
    if intent == "resource_allocation":
        return "check_jd_status"
    elif intent="handle_approval":
        return "handle_approval"
    elif intent == "leave_management":              # <-- ADD
        return "check_leave_status"                 # <-- ADD
    elif intent == "exit":
        return "handle_exit"
    elif intent == "other":
        return "handle_other"
    else:
        return "handle_unclear"