# agent/src/state/schemas.py
from typing import TypedDict, Optional, List
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from typing_extensions import Annotated

class AgentState(TypedDict):
    # Conversation
    messages: Annotated[List[BaseMessage], add_messages]
    session_id: str

    # Intent
    intent: Optional[str]
    intent_confidence: float

    # Agent control
    current_agent: Optional[str]
    agent_completed: bool
    awaiting_user: bool        #  HALT FLAG
    next_node: Optional[str]   #  Resume point

    #approval state
    needs_approval: bool
    result: str | None

    # Domain state
    extracted_requirements: Optional[dict]
    leave_request: Optional[dict]

    # Output
    response: Optional[dict]
    error: Optional[str]
