def classify_intent(state: AgentState) -> AgentState:
    user_message = state["messages"][-1].content

    result = llm.invoke(INTENT_CLASSIFIER_PROMPT + user_message)

    state["intent"] = result["intent"]
    state["intent_confidence"] = result.get("confidence", 0.9)

    return state
