from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from api.chat import chat_router

app = FastAPI(title="HR Recruitment Agent")

# Include chat routes
app.include_router(chat_router)

@app.get("/")
async def root():
    return {"status":200,"message": "HR Agent API running"}
